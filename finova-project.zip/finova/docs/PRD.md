# Finova — Product Requirements Document

**Version:** 1.0  
**Date:** May 2025  
**Author:** Finova Team  
**Status:** MVP

---

## 1. Overview

Finova is a lightweight invoice and receipt SaaS application designed for freelancers, solo founders, and small agencies. It enables users to create professional invoices, track payment statuses, generate receipts, and manage client relationships — all from a clean, minimal dashboard.

---

## 2. Problem Statement

Small business owners and freelancers struggle with:
- Creating professional-looking invoices quickly
- Tracking which invoices are paid, pending, or overdue
- Generating receipts for paid invoices to send to clients
- Keeping client records in one place

Finova solves all four problems with a no-frills, fast-to-use web application.

---

## 3. Goals

| Goal | Success Metric |
|------|---------------|
| Fast invoice creation | Invoice created in under 2 minutes |
| Clear payment tracking | Status visible at a glance |
| Receipt generation | One-click receipt from any paid invoice |
| Client management | All clients visible in one view |

---

## 4. Non-Goals (MVP)

- Multi-user teams / collaboration
- Stripe or payment gateway integration
- Email delivery of invoices
- Mobile native app
- Multi-currency support
- Tax automation / accounting integrations

---

## 5. User Personas

### Freelancer Femi
- A frontend developer billing 4–6 clients monthly
- Needs quick invoice creation with line items
- Wants to mark invoices paid and generate receipts instantly

### Agency Owner Amara
- Runs a 3-person creative agency
- Needs a client roster and revenue overview at a glance
- Values clean, professional-looking documents to send clients

---

## 6. Features

### 6.1 Authentication
- **Sign Up** — email + password registration
- **Sign In** — email + password login
- Session persisted in memory (MVP); localStorage in v2

### 6.2 Dashboard
- Revenue summary card (total from paid invoices)
- Outstanding amount card (sum of pending invoices)
- Total invoices count
- Total clients count
- Recent invoices table (last 5)
- Client list with invoice counts

### 6.3 Invoice List
- Table view: Invoice ID, Client, Issue Date, Due Date, Amount, Status, Actions
- Status badges: `Draft`, `Pending`, `Paid`
- Inline **Mark as Paid** button for draft/pending invoices
- **Generate Receipt** button for paid invoices
- **Delete** invoice

### 6.4 Create Invoice
- Client name and email fields
- Invoice date + due date pickers
- Status selector (Draft / Pending)
- Line items: description, quantity, rate → auto-calculated amount
- Add / remove line items dynamically
- Auto-calculated subtotal, 10% tax, and total
- Notes / payment terms field
- Save invoice → appears in invoice list
- Auto-creates new client record if client doesn't exist

### 6.5 Receipt Generation
- Modal view generated from any paid invoice
- Shows: invoice ID, client name/email, line items, subtotal, tax, total
- "PAID ✓" stamp
- Print-ready layout

### 6.6 Clients
- Table: Name, Company, Email, Phone, Invoice count, Total revenue
- **Add Client** modal with name, company, email, phone
- Revenue auto-calculated from paid invoices

### 6.7 Invoice Filtering (v1.1)
- Filter by status: All / Draft / Pending / Paid
- Search by client name or invoice ID

---

## 7. User Flows

### Create & Send Invoice
1. User clicks **New Invoice**
2. Fills client info, dates, line items
3. Sets status to **Pending**
4. Saves → appears in invoice list
5. Shares invoice ID or prints

### Mark Paid & Generate Receipt
1. User finds pending invoice in list
2. Clicks **Mark Paid** → status updates to Paid
3. Clicks **Receipt** → modal opens with receipt
4. Prints or screenshots receipt

---

## 8. UI Requirements

- **Color:** Primary green `#009A49`; light backgrounds `#F7F9FC`
- **Mode:** Light only (MVP)
- **Typography:** System sans-serif, clean hierarchy
- **Components:** Cards, tables, badges, modals
- **Responsiveness:** Desktop-first (MVP); mobile in v2

---

## 9. Technical Stack

| Layer | Technology |
|-------|-----------|
| Frontend | Vanilla JS / React (single file) |
| State | In-memory JS objects |
| Styling | CSS custom properties |
| Hosting | GitHub Pages / Netlify / Vercel |
| Backend | None (MVP — client-side only) |

---

## 10. Milestones

| Milestone | Scope | Target |
|-----------|-------|--------|
| MVP v1.0 | Auth, Dashboard, Invoices, Clients, Receipts | Week 1 |
| v1.1 | Filtering, PDF export, email simulation | Week 3 |
| v2.0 | Backend, real auth, Stripe, multi-user | Month 2 |

---

## 11. Open Questions

- Should invoice IDs be user-editable or always auto-generated?
- Do we need PDF export in MVP or is print-to-PDF sufficient?
- Should new clients added via invoice form be editable from the Clients page?
