# Finova — UI Style Guide

**Version:** 1.0  
**Product:** Finova Invoice & Receipt SaaS  
**Theme:** Clean SaaS Dashboard · Light Mode · Professional Green

---

## 1. Design Philosophy

Finova's UI is built on **clarity, trust, and speed**. Every design decision reduces cognitive load and helps users get their work done without friction.

> "A great SaaS tool is invisible. Users notice the outcome — not the interface."

Design principles:
- **Minimal chrome** — no decorative elements that don't carry meaning
- **Data-forward** — numbers, statuses, and actions are always prominent
- **Consistent rhythm** — uniform spacing, predictable patterns
- **Professional warmth** — green primary signals growth and financial health

---

## 2. Color System

### Primary Palette

| Token | Hex | Usage |
|-------|-----|-------|
| `--green` | `#009A49` | Primary actions, links, active nav, key accents |
| `--green-light` | `#E6F7EE` | Hover backgrounds, success fills, avatar backgrounds |
| `--green-mid` | `#00B857` | Hover state for primary buttons |
| `--green-dark` | `#007A3A` | Pressed / active state for primary buttons |

### Neutral Palette

| Token | Hex | Usage |
|-------|-----|-------|
| `--bg` | `#F7F9FC` | Page background |
| `--white` | `#FFFFFF` | Card surfaces, sidebar, topbar |
| `--border` | `#E2E8F0` | All borders and dividers |
| `--text` | `#1A2332` | Primary text, headings |
| `--muted` | `#64748B` | Secondary text, labels, placeholders |

### Semantic Colors

| State | Background | Text | Usage |
|-------|-----------|------|-------|
| Success / Paid | `#DCFCE7` | `#166534` | Paid badge |
| Warning / Pending | `#FEF9C3` | `#854D0E` | Pending badge |
| Neutral / Draft | `#F1F5F9` | `#64748B` | Draft badge |
| Danger | `#FEE2E2` | `#DC2626` | Delete, error states |

---

## 3. Typography

### Font Stack
```css
font-family: 'Segoe UI', system-ui, -apple-system, sans-serif;
```
No custom font loading in MVP — system fonts ensure fast load times and native feel.

### Scale

| Role | Size | Weight | Color |
|------|------|--------|-------|
| Page title (topbar) | 15px | 600 | `--text` |
| Section heading | 15px | 600 | `--text` |
| Stat value | 22px | 700 | `--text` |
| Table header | 11px | 600 | `--muted` · uppercase · 0.5px tracking |
| Table body | 14px | 400 | `--text` |
| Label (form) | 12px | 600 | `--muted` · uppercase · 0.4px tracking |
| Badge text | 11px | 600 | Semantic · uppercase · 0.4px tracking |
| Muted / secondary | 13px | 400 | `--muted` |
| Body / default | 14px | 400 | `--text` |

---

## 4. Spacing System

Base unit: **4px**. All spacing uses multiples of 4.

| Token | Value | Usage |
|-------|-------|-------|
| `xs` | 4px | Icon gaps, tight inline spacing |
| `sm` | 8px | Button padding, cell gaps |
| `md` | 12px | Component padding, row gaps |
| `lg` | 16px | Card padding, section gaps |
| `xl` | 24px | Page padding, section spacing |
| `2xl` | 32px | Large section separators |

---

## 5. Border Radius

| Context | Value |
|---------|-------|
| Buttons, inputs, badges, small elements | `6px` |
| Cards, modals, dropdowns | `10px` |
| Logo icon, avatar | `7–8px` |
| Pill badges (status) | `20px` |
| Avatar circles | `50%` |

---

## 6. Shadow System

Finova uses a single, minimal shadow level. No layered or dramatic shadows.

```css
--shadow: 0 1px 3px rgba(0, 0, 0, 0.08);
```

Used on: cards, stat blocks, modals.  
Not used on: buttons, inputs, nav items.

---

## 7. Component Patterns

### Cards
```css
background: #FFFFFF;
border: 1px solid #E2E8F0;
border-radius: 10px;
box-shadow: 0 1px 3px rgba(0,0,0,0.08);
```

### Stat Cards
```css
padding: 16px 20px;
/* Label: 12px, 500, muted, uppercase */
/* Value: 22px, 700 */
/* Subtext: 11px, muted */
```

### Buttons

**Primary**
```css
background: #009A49;
color: #fff;
padding: 8px 16px;
border-radius: 6px;
font-weight: 500;
```

**Outline**
```css
background: #fff;
color: #009A49;
border: 1px solid #009A49;
padding: 7px 14px;
```

**Ghost**
```css
background: transparent;
color: #64748B;
padding: 6px 10px;
/* hover: background #F1F5F9 */
```

### Tables
- Header: `11px` · `600` · uppercase · `#64748B` · `#FAFBFC` background
- Row: `1px solid #F1F5F9` bottom border
- Row hover: `background #FAFBFC`
- Cell padding: `11px 12px`

### Status Badges
- `border-radius: 20px` (pill)
- Uppercase, 11px, 600 weight
- Color-coded per semantic system (see Color System)

### Form Inputs
- `border: 1px solid #E2E8F0`
- `border-radius: 6px`
- `padding: 8px 10px`
- Focus: `border-color: #009A49` + `box-shadow: 0 0 0 3px rgba(0,154,73,0.10)`

### Sidebar Navigation
- Width: `200px`
- Active item: `background #E6F7EE`, `color #009A49`
- Hover: `background #F1F5F9`
- Item padding: `8px 10px`, `border-radius: 7px`

---

## 8. Iconography

Icons are inline SVG, 16×16px, `stroke-width: 1.7`, `stroke-linecap: round`, `stroke-linejoin: round`.  
All icons use `currentColor` to inherit text color.

Icon style: **outline only** — no filled icons in the primary UI.

---

## 9. Layout

### Page Layout
```
┌─────────────────────────────────────────┐
│  Sidebar (200px)  │  Main Content        │
│  Logo             │  Topbar (52px)       │
│  Nav items        │  ─────────────────  │
│  ─────────────    │  Page content        │
│  Sign out         │  (padding: 24px)     │
└─────────────────────────────────────────┘
```

### Dashboard Grid
- Stats: 4-column equal grid, `gap: 14px`
- Content: 2-column grid `1.6fr 1fr`, `gap: 16px`

### Topbar
- Height: `52px`
- `position: sticky; top: 0; z-index: 10`
- Right: user email + avatar initials circle

---

## 10. Motion & Interaction

Finova uses micro-transitions only — no page animations.

```css
transition: all 0.12s ease;   /* nav items, buttons */
transition: all 0.15s ease;   /* buttons (slightly slower) */
```

Focus states use `box-shadow` rings, never `outline: none` without replacement.

---

## 11. UI Voice & Content

- **Labels:** Sentence case, no periods (`Invoice date`, not `Invoice Date.`)
- **Buttons:** Verb-first (`Save Invoice`, `Mark Paid`, `Add Client`)
- **Empty states:** Friendly, action-oriented (`No invoices yet. Create your first one!`)
- **Errors:** Specific, calm (`Client name is required.`)
- **Badges:** Lowercase display words (`draft`, `pending`, `paid`)
